// Wrapper for CommonJS module
module.exports = require('./gateway-disk.cjs');